import { useState, useMemo } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, parseISO, isToday } from 'date-fns'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'

function CalendarView({ entries, month }) {
  const monthStart = startOfMonth(new Date(month + '-01'))
  const monthEnd = endOfMonth(monthStart)
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd })
  const startPadding = getDay(monthStart)
  const dayNames = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']

  const entryMap = useMemo(() => {
    const m = {}
    entries.forEach(e => { m[e.date] = e })
    return m
  }, [entries])

  return (
    <div>
      <div className="cal-grid">
        {dayNames.map(d => <div key={d} className="cal-day-name">{d}</div>)}
        {Array(startPadding).fill(null).map((_, i) => <div key={'pad-' + i} className="cal-day empty" />)}
        {days.map(day => {
          const dateStr = format(day, 'yyyy-MM-dd')
          const entry = entryMap[dateStr]
          let cls = 'cal-day unlogged'
          if (entry) cls = 'cal-day ' + (entry.taken ? 'taken' : 'skipped')
          if (isToday(day)) cls += ' today-marker'
          return (
            <div key={dateStr} className={cls} title={entry ? (entry.taken ? `Taken · ₹${entry.price} · ${entry.qty}L` : 'Skipped') : 'No entry'}>
              <span>{day.getDate()}</span>
              {entry && entry.taken && <span style={{ fontSize: 8, marginTop: 1 }}>₹{entry.price}</span>}
            </div>
          )
        })}
      </div>
      <div style={{ display: 'flex', gap: 16, marginTop: 12, fontSize: 12, color: 'var(--text-muted)' }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 12, height: 12, borderRadius: 3, background: '#F0FDF4', border: '1px solid #16A34A', display: 'inline-block' }} /> Taken
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 12, height: 12, borderRadius: 3, background: '#FEF2F2', border: '1px solid #DC2626', display: 'inline-block' }} /> Skipped
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 12, height: 12, borderRadius: 3, background: 'var(--bg)', display: 'inline-block' }} /> No entry
        </span>
      </div>
    </div>
  )
}

export default function MilkTracker() {
  const [entries, setEntries] = useLocalStorage('milk-entries', [])
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [taken, setTaken] = useState('yes')
  const [price, setPrice] = useState('')
  const [qty, setQty] = useState('')
  const [defaultPrice, setDefaultPrice] = useLocalStorage('milk-default-price', '')
  const [defaultQty, setDefaultQty] = useLocalStorage('milk-default-qty', '')
  const [msg, setMsg] = useState(null)
  const [viewMonth, setViewMonth] = useState(format(new Date(), 'yyyy-MM'))
  const [activeView, setActiveView] = useState('log')

  const months = useMemo(() => {
    const all = [...new Set(entries.map(e => e.date.slice(0, 7)))].sort().reverse()
    const cur = format(new Date(), 'yyyy-MM')
    if (!all.includes(cur)) all.unshift(cur)
    return all.slice(0, 6)
  }, [entries])

  const filtered = useMemo(() =>
    entries.filter(e => e.date.startsWith(viewMonth)).sort((a, b) => b.date.localeCompare(a.date)),
    [entries, viewMonth]
  )

  const stats = useMemo(() => {
    const taken = filtered.filter(e => e.taken)
    const skipped = filtered.filter(e => !e.taken)
    const totalCost = taken.reduce((s, e) => s + Number(e.price || 0), 0)
    const totalQty = taken.reduce((s, e) => s + Number(e.qty || 0), 0)
    const avgPrice = taken.length ? (totalCost / taken.length) : 0
    return { taken: taken.length, skipped: skipped.length, total: filtered.length, totalCost, totalQty, avgPrice }
  }, [filtered])

  const chartData = useMemo(() => {
    const byMonth = {}
    entries.filter(e => e.taken).forEach(e => {
      const m = e.date.slice(0, 7)
      if (!byMonth[m]) byMonth[m] = { month: m, cost: 0, days: 0 }
      byMonth[m].cost += Number(e.price || 0)
      byMonth[m].days += 1
    })
    return Object.values(byMonth).sort((a, b) => a.month.localeCompare(b.month)).slice(-6).map(d => ({
      ...d,
      label: format(parseISO(d.month + '-01'), 'MMM')
    }))
  }, [entries])

  const handleSubmit = () => {
    if (!date) return
    const existing = entries.findIndex(e => e.date === date)
    const entry = {
      date,
      taken: taken === 'yes',
      price: taken === 'yes' ? (price || defaultPrice || '') : '',
      qty: taken === 'yes' ? (qty || defaultQty || '') : '',
      updatedAt: new Date().toISOString()
    }
    let updated
    if (existing >= 0) {
      updated = [...entries]
      updated[existing] = entry
      setMsg({ type: 'success', text: 'Entry updated!' })
    } else {
      updated = [...entries, entry]
      setMsg({ type: 'success', text: 'Entry saved!' })
    }
    setEntries(updated)
    setPrice('')
    setQty('')
    setTimeout(() => setMsg(null), 3000)
  }

  const handleDelete = (d) => {
    setEntries(entries.filter(e => e.date !== d))
  }

  const todayStr = format(new Date(), 'yyyy-MM-dd')
  const todayEntry = entries.find(e => e.date === todayStr)

  return (
    <div>
      <div className="page-heading">
        <h1>🥛 Milk Tracker</h1>
        <p>Log daily milk deliveries, track cost & quantity</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: '1.25rem', alignItems: 'start' }}>

        {/* LEFT — Entry form */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {/* Today status */}
          {todayEntry && (
            <div className={`alert alert-${todayEntry.taken ? 'success' : 'danger'}`}>
              <span>{todayEntry.taken ? '✅' : '❌'}</span>
              Today: {todayEntry.taken ? `Taken · ₹${todayEntry.price} · ${todayEntry.qty}L` : 'Skipped'}
            </div>
          )}

          <div className="card">
            <div className="card-header">
              <span className="card-title">📝 Add / Update Entry</span>
            </div>
            <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div className="form-group">
                <label className="form-label">Date</label>
                <input type="date" className="form-input" value={date} max={todayStr} onChange={e => setDate(e.target.value)} />
              </div>

              <div className="form-group">
                <label className="form-label">Milk Taken?</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => setTaken('yes')}
                    className="btn btn-sm"
                    style={{ flex: 1, background: taken === 'yes' ? 'var(--success)' : 'var(--bg)', color: taken === 'yes' ? 'white' : 'var(--text-muted)', border: '1px solid var(--border-strong)' }}>
                    ✅ Yes, Taken
                  </button>
                  <button onClick={() => setTaken('no')}
                    className="btn btn-sm"
                    style={{ flex: 1, background: taken === 'no' ? 'var(--danger)' : 'var(--bg)', color: taken === 'no' ? 'white' : 'var(--text-muted)', border: '1px solid var(--border-strong)' }}>
                    ❌ Skipped
                  </button>
                </div>
              </div>

              {taken === 'yes' && (
                <div className="form-row">
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">Price (₹)</label>
                    <input type="number" className="form-input" value={price} onChange={e => setPrice(e.target.value)}
                      placeholder={defaultPrice || '0'} min="0" step="0.5" />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">Quantity (L)</label>
                    <input type="number" className="form-input" value={qty} onChange={e => setQty(e.target.value)}
                      placeholder={defaultQty || '0'} min="0" step="0.5" />
                  </div>
                </div>
              )}

              <button className="btn btn-primary btn-full" onClick={handleSubmit}>
                Save Entry
              </button>
              {msg && <div className={`alert alert-${msg.type}`}>{msg.text}</div>}
            </div>
          </div>

          {/* Defaults card */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">⚙️ Default Values</span>
            </div>
            <div className="card-body">
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12 }}>Pre-fill when adding entries</p>
              <div className="form-row">
                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label className="form-label">Default Price (₹)</label>
                  <input type="number" className="form-input" value={defaultPrice} onChange={e => setDefaultPrice(e.target.value)} placeholder="e.g. 60" />
                </div>
                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label className="form-label">Default Qty (L)</label>
                  <input type="number" className="form-input" value={defaultQty} onChange={e => setDefaultQty(e.target.value)} placeholder="e.g. 1" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT — Stats + History */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

          {/* Month picker */}
          <div className="month-filter">
            {months.map(m => (
              <button key={m} className={`month-chip ${viewMonth === m ? 'active' : ''}`} onClick={() => setViewMonth(m)}>
                {format(parseISO(m + '-01'), 'MMM yyyy')}
              </button>
            ))}
          </div>

          {/* Stats */}
          <div className="card">
            <div className="card-body" style={{ padding: '1rem 1.25rem' }}>
              <div className="stat-grid">
                <div className="stat-card">
                  <div className="stat-label">Days Taken</div>
                  <div className="stat-value" style={{ color: 'var(--success)' }}>{stats.taken}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Days Skipped</div>
                  <div className="stat-value" style={{ color: 'var(--danger)' }}>{stats.skipped}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Total Cost</div>
                  <div className="stat-value">₹{stats.totalCost.toFixed(0)}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Total Qty</div>
                  <div className="stat-value">{stats.totalQty.toFixed(1)}<span className="stat-unit">L</span></div>
                </div>
              </div>
            </div>
          </div>

          {/* View tabs */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">📅 {format(parseISO(viewMonth + '-01'), 'MMMM yyyy')}</span>
              <div style={{ display: 'flex', gap: 4 }}>
                <button className={`btn btn-sm ${activeView === 'calendar' ? 'btn-primary' : 'btn-outline'}`} onClick={() => setActiveView('calendar')}>Calendar</button>
                <button className={`btn btn-sm ${activeView === 'log' ? 'btn-primary' : 'btn-outline'}`} onClick={() => setActiveView('log')}>Log</button>
                <button className={`btn btn-sm ${activeView === 'chart' ? 'btn-primary' : 'btn-outline'}`} onClick={() => setActiveView('chart')}>Chart</button>
              </div>
            </div>
            <div className="card-body">
              {activeView === 'calendar' && <CalendarView entries={filtered} month={viewMonth} />}

              {activeView === 'log' && (
                filtered.length === 0
                  ? <div className="empty-state"><div className="empty-state-icon">🥛</div><p>No entries this month</p></div>
                  : <div className="log-scroll">
                    <div className="log-list">
                      {filtered.map(e => (
                        <div key={e.date} className="log-item">
                          <div>
                            <div className="log-date">{format(parseISO(e.date), 'dd MMM, EEE')}</div>
                            {e.taken
                              ? <div className="log-details">₹{e.price || '—'} · {e.qty || '—'}L</div>
                              : <div className="log-details" style={{ color: 'var(--danger)' }}>Skipped</div>
                            }
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <span className={`badge ${e.taken ? 'badge-taken' : 'badge-skipped'}`}>
                              {e.taken ? '✓ Taken' : '✗ Skip'}
                            </span>
                            <button className="btn btn-sm btn-outline" style={{ padding: '3px 8px', fontSize: 11 }}
                              onClick={() => handleDelete(e.date)}>✕</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
              )}

              {activeView === 'chart' && (
                chartData.length === 0
                  ? <div className="empty-state"><div className="empty-state-icon">📊</div><p>Not enough data yet</p></div>
                  : <div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12 }}>Monthly milk cost (₹)</div>
                    <ResponsiveContainer width="100%" height={180}>
                      <BarChart data={chartData} barSize={28}>
                        <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#9B9B9A' }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 11, fill: '#9B9B9A' }} axisLine={false} tickLine={false} width={40} />
                        <Tooltip formatter={(v) => ['₹' + v, 'Cost']} contentStyle={{ fontSize: 12 }} />
                        <Bar dataKey="cost" radius={[4, 4, 0, 0]}>
                          {chartData.map((d, i) => (
                            <Cell key={i} fill={d.month === viewMonth ? '#E8A020' : '#D3D1C7'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
