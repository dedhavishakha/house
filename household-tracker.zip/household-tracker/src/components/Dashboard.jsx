import { useMemo } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { format, parseISO, startOfMonth, endOfMonth, isToday, parseISO as parse } from 'date-fns'

export default function Dashboard({ onNavigate }) {
  const [milkEntries] = useLocalStorage('milk-entries', [])
  const [elecReadings] = useLocalStorage('electricity-readings', [])

  const thisMonth = format(new Date(), 'yyyy-MM')
  const todayStr = format(new Date(), 'yyyy-MM-dd')

  const milkStats = useMemo(() => {
    const monthly = milkEntries.filter(e => e.date.startsWith(thisMonth))
    const taken = monthly.filter(e => e.taken)
    const skipped = monthly.filter(e => !e.taken)
    const cost = taken.reduce((s, e) => s + Number(e.price || 0), 0)
    const qty = taken.reduce((s, e) => s + Number(e.qty || 0), 0)
    const todayEntry = milkEntries.find(e => e.date === todayStr)
    return { taken: taken.length, skipped: skipped.length, cost, qty, todayEntry, total: monthly.length }
  }, [milkEntries, thisMonth, todayStr])

  const elecStats = useMemo(() => {
    const sorted = [...elecReadings].sort((a, b) => b.date.localeCompare(a.date))
    const latest = sorted[0]
    const totalPaid = elecReadings.reduce((s, r) => s + Number(r.amountPaid || 0), 0)
    const lastTwo = [...elecReadings].sort((a, b) => a.date.localeCompare(b.date)).slice(-2)
    const lastUnits = lastTwo.length === 2 ? Math.max(0, Number(lastTwo[1].reading) - Number(lastTwo[0].reading)) : null
    return { latest, totalPaid, lastUnits, count: elecReadings.length }
  }, [elecReadings])

  const recentMilk = useMemo(() =>
    [...milkEntries].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5),
    [milkEntries]
  )

  const recentElec = useMemo(() =>
    [...elecReadings].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 4),
    [elecReadings]
  )

  return (
    <div>
      <div className="page-heading">
        <h1>Good {getGreeting()}, tracking made simple 👋</h1>
        <p>Here's your household overview for {format(new Date(), 'MMMM yyyy')}</p>
      </div>

      {/* Today status row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
        <div className="card" style={{ cursor: 'pointer', borderLeft: '3px solid var(--milk-color)' }} onClick={() => onNavigate('milk')}>
          <div className="card-body" style={{ padding: '1rem 1.25rem' }}>
            <div style={{ display: 'flex', align: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              <div style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>🥛 Today's Milk</div>
              <span style={{ fontSize: 11, color: 'var(--elec-color)' }}>Log →</span>
            </div>
            {milkStats.todayEntry
              ? <div>
                <span className={`badge ${milkStats.todayEntry.taken ? 'badge-taken' : 'badge-skipped'}`}>
                  {milkStats.todayEntry.taken ? '✓ Taken' : '✗ Skipped'}
                </span>
                {milkStats.todayEntry.taken && (
                  <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>
                    ₹{milkStats.todayEntry.price} · {milkStats.todayEntry.qty}L
                  </div>
                )}
              </div>
              : <div style={{ fontSize: 13, color: 'var(--danger)', fontWeight: 500 }}>⚠ Not logged yet</div>
            }
          </div>
        </div>

        <div className="card" style={{ cursor: 'pointer', borderLeft: '3px solid var(--elec-color)' }} onClick={() => onNavigate('electricity')}>
          <div className="card-body" style={{ padding: '1rem 1.25rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              <div style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>⚡ Meter Reading</div>
              <span style={{ fontSize: 11, color: 'var(--elec-color)' }}>Add →</span>
            </div>
            {elecStats.latest
              ? <div>
                <div style={{ fontFamily: 'Syne', fontSize: 20, fontWeight: 700 }}>{elecStats.latest.reading} <span style={{ fontSize: 13, fontWeight: 400 }}>units</span></div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{format(parseISO(elecStats.latest.date), 'dd MMM yyyy')}</div>
              </div>
              : <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>No readings yet</div>
            }
          </div>
        </div>
      </div>

      {/* Main stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem', marginBottom: '1.5rem' }}>

        {/* Milk summary */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">🥛 Milk — {format(new Date(), 'MMM yyyy')}</span>
            <button className="btn btn-sm btn-outline" onClick={() => onNavigate('milk')}>View all</button>
          </div>
          <div className="card-body">
            <div className="stat-grid" style={{ gridTemplateColumns: '1fr 1fr', marginBottom: 16 }}>
              <div className="stat-card">
                <div className="stat-label">Days Taken</div>
                <div className="stat-value" style={{ color: 'var(--success)' }}>{milkStats.taken}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Days Skipped</div>
                <div className="stat-value" style={{ color: 'var(--danger)' }}>{milkStats.skipped}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Total Spent</div>
                <div className="stat-value">₹{milkStats.cost.toFixed(0)}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Total Qty</div>
                <div className="stat-value">{milkStats.qty.toFixed(1)}<span className="stat-unit">L</span></div>
              </div>
            </div>

            {/* Attendance bar */}
            {milkStats.total > 0 && (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-hint)', marginBottom: 4 }}>
                  <span>Delivery rate</span>
                  <span>{Math.round((milkStats.taken / milkStats.total) * 100)}%</span>
                </div>
                <div style={{ height: 6, background: 'var(--bg)', borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${(milkStats.taken / milkStats.total) * 100}%`, background: 'var(--success)', borderRadius: 3, transition: 'width 0.4s' }} />
                </div>
              </div>
            )}

            {recentMilk.length > 0 && (
              <div style={{ marginTop: 14 }}>
                <div className="section-heading">Recent</div>
                <div className="log-list">
                  {recentMilk.map(e => (
                    <div key={e.date} className="log-item" style={{ padding: '8px 12px' }}>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 500 }}>{format(parseISO(e.date), 'dd MMM, EEE')}</div>
                        {e.taken && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>₹{e.price} · {e.qty}L</div>}
                      </div>
                      <span className={`badge ${e.taken ? 'badge-taken' : 'badge-skipped'}`} style={{ fontSize: 10 }}>
                        {e.taken ? '✓' : '✗'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Electricity summary */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">⚡ Electricity</span>
            <button className="btn btn-sm btn-outline" onClick={() => onNavigate('electricity')}>View all</button>
          </div>
          <div className="card-body">
            <div className="stat-grid" style={{ gridTemplateColumns: '1fr 1fr', marginBottom: 16 }}>
              <div className="stat-card">
                <div className="stat-label">Total Paid</div>
                <div className="stat-value">₹{elecStats.totalPaid.toFixed(0)}</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Readings</div>
                <div className="stat-value">{elecStats.count}</div>
              </div>
              <div className="stat-card" style={{ gridColumn: '1 / -1' }}>
                <div className="stat-label">Latest Meter</div>
                <div className="stat-value" style={{ fontSize: 20 }}>
                  {elecStats.latest ? elecStats.latest.reading : '—'}
                  {elecStats.latest && <span className="stat-unit">units</span>}
                </div>
              </div>
            </div>

            {elecStats.lastUnits !== null && (
              <div style={{ padding: '10px 12px', background: 'var(--elec-light)', borderRadius: 8, marginBottom: 14 }}>
                <div style={{ fontSize: 11, color: 'var(--elec-color)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.3px' }}>Last Bill Period</div>
                <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--elec-color)', fontFamily: 'Syne' }}>{elecStats.lastUnits} units consumed</div>
              </div>
            )}

            {recentElec.length > 0 && (
              <div>
                <div className="section-heading">Recent Readings</div>
                <div className="log-list">
                  {recentElec.map((r, i) => {
                    const prev = [...elecReadings].sort((a, b) => a.date.localeCompare(b.date))
                    const idx = prev.findIndex(x => x.id === r.id)
                    const prevR = idx > 0 ? prev[idx - 1] : null
                    const units = prevR ? Math.max(0, Number(r.reading) - Number(prevR.reading)) : null
                    return (
                      <div key={r.id} className="log-item" style={{ padding: '8px 12px' }}>
                        <div>
                          <div style={{ fontSize: 12, fontWeight: 500 }}>{format(parseISO(r.date), 'dd MMM yyyy')}</div>
                          <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                            {r.reading} u {units !== null && `· +${units}`}
                          </div>
                        </div>
                        {r.amountPaid && <span className="badge badge-elec">₹{r.amountPaid}</span>}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {elecStats.count === 0 && (
              <div className="empty-state">
                <div className="empty-state-icon">⚡</div>
                <p>No readings yet. Add your first!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function getGreeting() {
  const h = new Date().getHours()
  if (h < 12) return 'good morning'
  if (h < 17) return 'good afternoon'
  return 'good evening'
}
