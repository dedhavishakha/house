import { useState, useMemo } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { format, parseISO } from 'date-fns'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

export default function ElectricityTracker() {
  const [readings, setReadings] = useLocalStorage('electricity-readings', [])
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [reading, setReading] = useState('')
  const [amountPaid, setAmountPaid] = useState('')
  const [msg, setMsg] = useState(null)
  const [editId, setEditId] = useState(null)
  const todayStr = format(new Date(), 'yyyy-MM-dd')

  const sorted = useMemo(() =>
    [...readings].sort((a, b) => b.date.localeCompare(a.date)), [readings])

  const chartData = useMemo(() => {
    const asc = [...readings].sort((a, b) => a.date.localeCompare(b.date))
    return asc.map((r, i) => {
      const units = i > 0 ? (Number(r.reading) - Number(asc[i - 1].reading)) : 0
      return {
        label: format(parseISO(r.date), 'MMM d'),
        reading: Number(r.reading),
        units: Math.max(0, units),
        paid: Number(r.amountPaid || 0)
      }
    }).filter((_, i) => i > 0 || asc.length === 1)
  }, [readings])

  const stats = useMemo(() => {
    const totalPaid = readings.reduce((s, r) => s + Number(r.amountPaid || 0), 0)
    const lastTwo = [...readings].sort((a, b) => a.date.localeCompare(b.date)).slice(-2)
    const unitsLastBill = lastTwo.length === 2
      ? Math.max(0, Number(lastTwo[1].reading) - Number(lastTwo[0].reading))
      : null
    const latestReading = sorted[0]
    return { totalPaid, unitsLastBill, latestReading, count: readings.length }
  }, [readings, sorted])

  const handleSubmit = () => {
    if (!date || !reading) return
    const id = editId || Date.now().toString()
    const entry = { id, date, reading, amountPaid, createdAt: new Date().toISOString() }
    if (editId) {
      setReadings(readings.map(r => r.id === editId ? entry : r))
      setMsg({ type: 'success', text: 'Reading updated!' })
      setEditId(null)
    } else {
      const existing = readings.find(r => r.date === date)
      if (existing) {
        setReadings(readings.map(r => r.date === date ? { ...r, reading, amountPaid } : r))
        setMsg({ type: 'success', text: 'Reading updated for this date!' })
      } else {
        setReadings([...readings, entry])
        setMsg({ type: 'success', text: 'Reading saved!' })
      }
    }
    setReading('')
    setAmountPaid('')
    setDate(todayStr)
    setTimeout(() => setMsg(null), 3000)
  }

  const handleEdit = (r) => {
    setEditId(r.id)
    setDate(r.date)
    setReading(r.reading)
    setAmountPaid(r.amountPaid || '')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleDelete = (id) => {
    setReadings(readings.filter(r => r.id !== id))
  }

  const unitRate = useMemo(() => {
    const withUnits = chartData.filter(d => d.units > 0 && d.paid > 0)
    if (!withUnits.length) return null
    const last = withUnits[withUnits.length - 1]
    return (last.paid / last.units).toFixed(2)
  }, [chartData])

  return (
    <div>
      <div className="page-heading">
        <h1>⚡ Electricity Tracker</h1>
        <p>Log meter readings and bill payments</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: '1.25rem', alignItems: 'start' }}>

        {/* LEFT — Form */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

          {stats.latestReading && (
            <div className="alert alert-success">
              <span>📍</span>
              Last reading: <strong>{stats.latestReading.reading} units</strong> on {format(parseISO(stats.latestReading.date), 'dd MMM yyyy')}
            </div>
          )}

          <div className="card">
            <div className="card-header">
              <span className="card-title">📝 {editId ? 'Edit Reading' : 'Add Reading'}</span>
              {editId && (
                <button className="btn btn-sm btn-outline" onClick={() => { setEditId(null); setReading(''); setAmountPaid(''); setDate(todayStr) }}>Cancel</button>
              )}
            </div>
            <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div className="form-group">
                <label className="form-label">Reading Date</label>
                <input type="date" className="form-input" value={date} max={todayStr} onChange={e => setDate(e.target.value)} />
              </div>

              <div className="form-group">
                <label className="form-label">Meter Reading (kWh units)</label>
                <input type="number" className="form-input" value={reading} onChange={e => setReading(e.target.value)}
                  placeholder="e.g. 4520" min="0" step="1" />
                {stats.latestReading && reading && Number(reading) > Number(stats.latestReading.reading) && (
                  <div style={{ fontSize: 12, color: 'var(--success)', marginTop: 4 }}>
                    ↑ {Number(reading) - Number(stats.latestReading.reading)} units since last reading
                  </div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Amount Paid (₹) — Bill Amount</label>
                <input type="number" className="form-input" value={amountPaid} onChange={e => setAmountPaid(e.target.value)}
                  placeholder="e.g. 1450" min="0" />
                <div style={{ fontSize: 11, color: 'var(--text-hint)', marginTop: 4 }}>Leave blank if reading only, fill when paying bill</div>
              </div>

              <button className="btn btn-primary btn-full" onClick={handleSubmit} disabled={!date || !reading}>
                {editId ? '✓ Update Reading' : '+ Save Reading'}
              </button>
              {msg && <div className={`alert alert-${msg.type}`}>{msg.text}</div>}
            </div>
          </div>

          {/* Rate card */}
          {unitRate && (
            <div className="card" style={{ borderLeft: '3px solid var(--elec-color)' }}>
              <div className="card-body" style={{ padding: '1rem 1.25rem' }}>
                <div className="stat-label">Estimated Rate (last bill)</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 4 }}>
                  <span style={{ fontFamily: 'Syne', fontSize: 24, fontWeight: 700 }}>₹{unitRate}</span>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>per unit</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* RIGHT — Stats + History */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

          {/* Stats */}
          <div className="card">
            <div className="card-body" style={{ padding: '1rem 1.25rem' }}>
              <div className="stat-grid">
                <div className="stat-card">
                  <div className="stat-label">Total Paid</div>
                  <div className="stat-value">₹{stats.totalPaid.toFixed(0)}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Last Bill Units</div>
                  <div className="stat-value">
                    {stats.unitsLastBill !== null ? stats.unitsLastBill : '—'}
                    {stats.unitsLastBill !== null && <span className="stat-unit">u</span>}
                  </div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Readings Saved</div>
                  <div className="stat-value">{stats.count}</div>
                </div>
                <div className="stat-card">
                  <div className="stat-label">Latest Meter</div>
                  <div className="stat-value" style={{ fontSize: 18 }}>
                    {stats.latestReading ? stats.latestReading.reading : '—'}
                    {stats.latestReading && <span className="stat-unit">u</span>}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Chart */}
          {chartData.length > 1 && (
            <div className="card">
              <div className="card-header">
                <span className="card-title">📈 Units Consumed per Period</span>
              </div>
              <div className="card-body">
                <ResponsiveContainer width="100%" height={170}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#9B9B9A' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: '#9B9B9A' }} axisLine={false} tickLine={false} width={36} />
                    <Tooltip formatter={(v, n) => [n === 'paid' ? '₹' + v : v + ' u', n === 'paid' ? 'Paid' : 'Units']} contentStyle={{ fontSize: 12 }} />
                    <Line type="monotone" dataKey="units" stroke="#2563EB" strokeWidth={2} dot={{ r: 3 }} name="units" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Reading history */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">📋 Reading History</span>
              <span style={{ fontSize: 12, color: 'var(--text-hint)' }}>{sorted.length} entries</span>
            </div>
            <div className="card-body">
              {sorted.length === 0
                ? <div className="empty-state"><div className="empty-state-icon">⚡</div><p>No readings yet</p></div>
                : <div className="log-scroll">
                  <div className="log-list">
                    {sorted.map((r, i) => {
                      const prev = sorted[i + 1]
                      const units = prev ? Math.max(0, Number(r.reading) - Number(prev.reading)) : null
                      return (
                        <div key={r.id} className="log-item">
                          <div>
                            <div className="log-date">{format(parseISO(r.date), 'dd MMM yyyy')}</div>
                            <div className="log-details">
                              {r.reading} units
                              {units !== null && <span> · +{units} from prev</span>}
                              {r.amountPaid && <span> · <strong style={{ color: 'var(--elec-color)' }}>₹{r.amountPaid} paid</strong></span>}
                            </div>
                          </div>
                          <div style={{ display: 'flex', gap: 6 }}>
                            {r.amountPaid && <span className="badge badge-elec">Paid</span>}
                            <button className="btn btn-sm btn-outline" style={{ padding: '3px 8px', fontSize: 11 }} onClick={() => handleEdit(r)}>✎</button>
                            <button className="btn btn-sm btn-outline" style={{ padding: '3px 8px', fontSize: 11 }} onClick={() => handleDelete(r.id)}>✕</button>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
